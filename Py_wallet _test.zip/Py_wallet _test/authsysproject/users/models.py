from django.db import models

# Create your models here.
class User(models.Model):
    username=models.CharField(max_length=30)
    balance=models.IntegerField(default=100)
    add=models.IntegerField(default=0)
    remove=models.IntegerField(default=0)

    def __str__(self):
       return str(self.balance+self.add)

