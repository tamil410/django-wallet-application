from datetime import datetime
from django.db import models

# Create your models here.
class User(models.Model):
    username=models.CharField(max_length=30)
    balance=models.IntegerField(default=10)
    
    def __str__(self):
        return str(self.balance)

    

class Trans(models.Model):
    username=models.CharField(max_length=30)
    add=models.IntegerField(default=0)
    time=models.DateTimeField(default=datetime.now())

    def __str__(self):
        abo=str(self.username)+' added an amount of ' + str(self.add) + ' on ' +str(self.time)
        return abo

